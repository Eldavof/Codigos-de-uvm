#include <iostream>
#include <queue>

using namespace std;

int main() {
    // Declaraci�n de la cola
    queue<string> lista;

    // --- Agregar elementos a la lista ---
    string elemento;
    int mas = 1;

    do {
        cout << "Escribe un nombre: \n";
        cin >> elemento;
        lista.push(elemento);
        mas++;
    } while (mas <= 5);

    // Agregamos dos nombres extra manualmente
    lista.push("Juan");
    lista.push("Pedro");

    cout << "\nLa cantidad de elementos en la lista es: " << lista.size() << endl;
    cout << "\nContenido en la lista:\n";

    // --- Mostrar elementos de la lista ---
    while (!lista.empty()) {
        cout << lista.front() << endl; // Muestra el elemento del frente
        lista.pop();                   // Elimina el elemento del frente
    }

    cout << "La cantidad de elementos en la lista es: " << lista.size() << endl;

    return 0;
}
