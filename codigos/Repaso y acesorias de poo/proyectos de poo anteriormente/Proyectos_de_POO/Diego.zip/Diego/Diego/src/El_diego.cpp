#include "El_diego.h"
#include <iostream>
using namespace std;

void El_diego::RegistrarDatos()
{
cout<<"diego solto la sopa"<<endl;
}

void El_diego::MostrarDatos()
{
    cout<<" Diego "<<" esta en "<<clase<<" esta jugando "<<juego<<endl;
    cout<<" y dijo que no a usado chati: "<<chati<<"veces"<<endl;
}
