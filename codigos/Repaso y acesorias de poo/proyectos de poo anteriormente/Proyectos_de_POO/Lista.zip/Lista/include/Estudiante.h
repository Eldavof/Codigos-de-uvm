#ifndef ESTUDIANTE_H
#define ESTUDIANTE_H

#include <string>
#include <iostream>

using namespace std;

class Student {
private:
    int id;
    string nombre;
    double promedio; // 0.0 - 100.0

public:
    // Constructor
    Student(int id = 0, string nombre = "", double promedio = 0.0);

    // Getters
    int getId() const;
    const string& getNombre() const;
    double getPromedio() const;

    // Setters
    void setNombre(const std::string& n);
    void setPromedio(double p);

    // Utilidad
    string toString() const;

    // Operador de igualdad (necesario para b�squedas internas de la lista)
    bool operator==(const Student& other) const {
        return id == other.id;
    }
};

// Comparadores libres (para usar en sort)
bool byIdAsc(const Student& a, const Student& b);
bool byPromedioDesc(const Student& a, const Student& b);

#endif // ESTUDIANTE_H
