#ifndef LISTAESTUDIANTE_H
#define LISTAESTUDIANTE_H

#include <list>
#include "Estudiante.h"

using namespace std;

class StudentList {
private:
    list<Student> datos;

public:
    // Agregar
    void agregar(const Student& s);
    void agregarAlFrente(const Student& s);

    // Eliminar y Buscar
    bool eliminarPorId(int id);
    Student* buscarPorId(int id);

    // Ordenar
    void ordenarPorId();
    void ordenarPorPromedioDesc();

    // Filtrar
    void eliminarReprobados(double corte);

    // Fusionar
    void fusionarCon(StudentList& otra);

    // Utilidad
    void imprimir() const;
    size_t size() const;
    void limpiar();
};

#endif // LISTAESTUDIANTE_H
