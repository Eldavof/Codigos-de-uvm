#include <iostream>
#include "ListaEstudiante.h"

using namespace std;

int main() {
    cout << "Demostracion de std::list con POO (Estudiantes)\n\n";

    StudentList grupoA;

    // 1. Agregar
    grupoA.agregar(Student(101, "Ana", 92.5));
    grupoA.agregar(Student(102, "Luis", 75.0));
    grupoA.agregar(Student(103, "Sofia", 58.0));
    grupoA.agregarAlFrente(Student(100, "Carlos", 81.2));

    cout << "Estado inicial:\n";
    grupoA.imprimir();

    // 2. Buscar y Modificar
    if (auto* s = grupoA.buscarPorId(102)) {
        cout << "\nEncontrado ID 102 -> " << s->toString() << "\n";
        s->setPromedio(78.0);
        cout << "Actualizado promedio de Luis -> " << s->toString() << "\n";
    }

    // 3. Ordenar
    grupoA.ordenarPorPromedioDesc();
    cout << "\nOrdenado por promedio desc:\n";
    grupoA.imprimir();

    // 4. Eliminar Reprobados
    grupoA.eliminarReprobados(60.0);
    cout << "\nTras eliminar reprobados (<60):\n";
    grupoA.imprimir();

    // 5. Eliminar por ID
    bool eliminado = grupoA.eliminarPorId(100);
    cout << "\nEliminar ID 100 -> " << (eliminado ? "OK" : "No encontrado") << "\n";
    grupoA.imprimir();

    // 6. Fusionar listas
    StudentList grupoB;
    grupoB.agregar(Student(201, "Martha", 85.0));
    grupoB.agregar(Student(202, "Ricardo", 90.0));

    cout << "\nFusionando grupoB en grupoA...\n";
    grupoA.fusionarCon(grupoB);
    grupoA.imprimir();

    return 0;
}
