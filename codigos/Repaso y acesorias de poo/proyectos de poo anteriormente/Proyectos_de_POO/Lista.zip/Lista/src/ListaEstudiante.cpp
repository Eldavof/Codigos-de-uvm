#include "ListaEstudiante.h"
#include <iostream>
#include <algorithm> // Necesario para algoritmos extra si usaras vectores, pero bueno tenerlo

using namespace std;

void StudentList::agregar(const Student& s) {
    datos.push_back(s);
}

void StudentList::agregarAlFrente(const Student& s) {
    datos.push_front(s);
}

// --- CORREGIDO: Ahora s� elimina ---
bool StudentList::eliminarPorId(int id) {
    auto before = datos.size();

    // Esta es la l�nea m�gica que faltaba en tu captura:
    datos.remove_if([id](const Student& s) { return s.getId() == id; });

    return datos.size() < before; // Retorna true si el tama�o cambi�
}

Student* StudentList::buscarPorId(int id) {
    for (auto& s : datos) {
        if (s.getId() == id) return &s;
    }
    return nullptr;
}

void StudentList::ordenarPorId() {
    datos.sort(byIdAsc);
}

void StudentList::ordenarPorPromedioDesc() {
    datos.sort(byPromedioDesc);
}

// --- CORREGIDO: Estaba comentado en tu captura ---
void StudentList::eliminarReprobados(double corte) {
    datos.remove_if([corte](const Student& s) {
        return s.getPromedio() < corte;
    });
}

void StudentList::fusionarCon(StudentList& otra) {
    datos.splice(datos.end(), otra.datos);
}

void StudentList::imprimir() const {
    cout << "---- Lista de estudiantes (" << datos.size() << ") ----\n";
    for (const auto& s : datos) {
        cout << "  " << s.toString() << "\n";
    }
    cout << "------------------------------------------\n";
}

size_t StudentList::size() const {
    return datos.size();
}

void StudentList::limpiar() {
    datos.clear();
}
