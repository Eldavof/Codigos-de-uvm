#include "Estudiante.h"
#include <sstream>
#include <iomanip>
#include <stdexcept>
#include <iostream>

using namespace std;

// --- Constructor ---
Student::Student(int id, string nombre, double promedio)
    : id(id), nombre(move(nombre)), promedio(promedio) {
    if (promedio < 0.0 || promedio > 100.0) {
        throw out_of_range("Promedio fuera de rango [0, 100]");
    }
}

// --- Getters ---
int Student::getId() const { return id; }
const string& Student::getNombre() const { return nombre; }
double Student::getPromedio() const { return promedio; }

// --- Setters ---
void Student::setNombre(const string& n) { nombre = n; }

void Student::setPromedio(double p) {
    if (p < 0.0 || p > 100.0) {
        throw out_of_range("Promedio fuera de rango [0, 100]");
    }
    promedio = p;
}

// --- Utilidad ---
string Student::toString() const {
    ostringstream os;
    os << "ID: " << id
       << " | Nombre: " << nombre
       << " | Promedio: " << fixed << setprecision(1) << promedio;
    return os.str();
}

// --- Comparadores ---
bool byIdAsc(const Student& a, const Student& b) {
    return a.getId() < b.getId();
}

bool byPromedioDesc(const Student& a, const Student& b) {
    return a.getPromedio() > b.getPromedio();
}
