#include <iostream>
#include <stack>

using namespace std;

int main() {
    stack<int> pila;

    cout << "--- LLENANDO LA PILA ---\n";
    // 1. Primero llenamos la pila completamente
    for (int i = 10; i <= 20; i++) {
        pila.push(i);
        cout << "Agregado: " << i << " (Tama�o actual: " << pila.size() << ")" << endl;
    }

    cout << "\nEl ultimo elemento agregado fue: " << pila.top() << endl;
    cout << "Total elementos final: " << pila.size() << endl;

    cout << "\n--- VACIANDO LA PILA (LIFO) ---\n";
    // 2. Luego vaciamos la pila
    // Notar�s que salen en orden inverso (del 20 al 10)
    while (!pila.empty()) {
        cout << "Sacando: " << pila.top() << endl;
        pila.pop(); // Elimina el elemento superior
    }

    cout << "\nLa pila ahora esta vacia." << endl;

    return 0;
}
