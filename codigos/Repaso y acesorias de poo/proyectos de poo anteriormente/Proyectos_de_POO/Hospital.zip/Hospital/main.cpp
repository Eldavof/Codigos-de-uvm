#include <iostream>
#include <locale.h>  // Para caracteres en espa�ol
#include <cstdlib>   // Necesario para system("CLS") y system("PAUSE")
#include "Paciente.h"

using namespace std;

const int MAX_PACIENTES = 100;

int main() {
    // Configurar idioma para mostrar tildes y �
    setlocale(LC_CTYPE, "spanish");

    // Arreglo de punteros para almacenar los pacientes
    Paciente *pacientes[MAX_PACIENTES];
    int total = 0;
    int opcion, i;

    do {
        system("CLS"); // Limpiar pantalla
        cout << "\n--- Men� Hospital ---" << endl;
        cout << "1. Agregar paciente" << endl;
        cout << "2. Mostrar pacientes" << endl;
        cout << "3. Modificar paciente" << endl;
        cout << "4. Salir" << endl;
        cout << "Seleccione una opci�n: ";
        cin >> opcion;
        cin.ignore(); // Limpiar el buffer despu�s de leer un n�mero

        switch (opcion) {
            case 1: {
                if (total < MAX_PACIENTES) {
                    string nombre, enfermedad;
                    int edad;

                    cout << "Nombre: ";
                    getline(cin, nombre);

                    cout << "Edad: ";
                    cin >> edad;
                    cin.ignore(); // Importante antes de usar otro getline

                    cout << "Enfermedad: ";
                    getline(cin, enfermedad);

                    // Crear el nuevo paciente y guardarlo en el arreglo
                    pacientes[total] = new Paciente(nombre, edad, enfermedad);
                    total++;
                    cout << "\nPaciente agregado exitosamente." << endl;
                } else {
                    cout << "Capacidad m�xima alcanzada." << endl;
                }
                system("PAUSE");
                break;
            }

            case 2: {
                // Recorrer y mostrar todos los pacientes
                for (i = 0; i < total; i++) {
                    cout << "\nPaciente #" << i + 1 << endl;
                    pacientes[i]->mostrarInfo();
                }
                if (total == 0) {
                    cout << "\nNo hay pacientes registrados." << endl;
                }
                system("PAUSE");
                break;
            }

            case 3: {
                int index;
                cout << "Ingrese el n�mero del paciente a modificar: ";
                cin >> index;
                cin.ignore();

                // Verificar que el �ndice sea v�lido (1 a total)
                if (index > 0 && index <= total) {
                    Paciente* p = pacientes[index - 1]; // Ajustamos �ndice (usuario ve 1, arreglo es 0)

                    string nombre, enfermedad;
                    int edad;

                    // Mostrar datos actuales y pedir nuevos
                    cout << "Nuevo nombre (" << p->getNombre() << "): ";
                    getline(cin, nombre);

                    cout << "Nueva edad (" << p->getEdad() << "): ";
                    cin >> edad;
                    cin.ignore();

                    cout << "Nueva enfermedad (" << p->getEnfermedad() << "): ";
                    getline(cin, enfermedad);

                    // Actualizar datos usando los Setters
                    p->setNombre(nombre);
                    p->setEdad(edad);
                    p->setEnfermedad(enfermedad);

                    cout << "\nDatos actualizados correctamente." << endl;
                } else {
                    cout << "N�mero inv�lido." << endl;
                }
                system("PAUSE");
                break;
            }

            case 4:
                cout << "Saliendo del sistema..." << endl;
                break;

            default:
                cout << "Opci�n no v�lida." << endl;
                system("PAUSE");
        }

    } while (opcion != 4);

    // --- Limpieza de Memoria ---
    // Como usamos 'new', debemos usar 'delete' antes de terminar
    for (int i = 0; i < total; i++) {
        delete pacientes[i];
    }

    return 0;
}
