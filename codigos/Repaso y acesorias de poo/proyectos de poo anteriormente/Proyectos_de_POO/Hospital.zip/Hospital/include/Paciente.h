#ifndef PACIENTE_H
#define PACIENTE_H

#include <string>

using namespace std;

class Paciente {
private:
    string nombre;
    int edad;
    string enfermedad;

public:
    // --- Constructores y Destructor ---
    Paciente(); // Constructor por defecto
    Paciente(string _nombre, int _edad, string _enfermedad); // Constructor con par�metros
    ~Paciente(); // Destructor

    // --- Getters (Obtener valores) ---
    string getNombre();
    int getEdad();
    string getEnfermedad();

    // --- Setters (Modificar valores) ---
    void setNombre(string _nombre);
    void setEdad(int _edad);
    void setEnfermedad(string _enfermedad);

    // --- Otros m�todos ---
    void mostrarInfo();
};

#endif // PACIENTE_H
