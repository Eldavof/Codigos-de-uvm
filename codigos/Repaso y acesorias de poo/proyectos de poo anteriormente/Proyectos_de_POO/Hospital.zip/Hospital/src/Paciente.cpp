#include "Paciente.h"
#include <iostream>

using namespace std;

// --- Constructor por defecto ---
// Inicializa al paciente con valores vac�os
Paciente::Paciente() {
    nombre = "";
    edad = 0;
    enfermedad = "";
    cout << "[Constructor] Paciente creado." << endl;
}

// --- Constructor con par�metros ---
// Inicializa al paciente con los datos que le pasamos
Paciente::Paciente(string _nombre, int _edad, string _enfermedad) {
    nombre = _nombre;
    edad = _edad;
    enfermedad = _enfermedad;
    cout << "[Constructor] Paciente creado: " << nombre << endl;
}

// --- Destructor ---
// Se ejecuta autom�ticamente cuando el objeto se elimina de la memoria
Paciente::~Paciente() {
    cout << "[Destructor] Paciente eliminado: " << nombre << endl;
}

// --- Getters (Obtener valores) ---

string Paciente::getNombre() {
    return nombre;
}

int Paciente::getEdad() {
    return edad;
}

string Paciente::getEnfermedad() {
    return enfermedad;
}

// --- Setters (Modificar valores) ---

void Paciente::setNombre(string _nombre) {
    nombre = _nombre;
}

void Paciente::setEdad(int _edad) {
    edad = _edad;
}

void Paciente::setEnfermedad(string _enfermedad) {
    enfermedad = _enfermedad;
}

// --- M�todo para mostrar informaci�n ---
void Paciente::mostrarInfo() {
    cout << "Nombre: " << nombre << endl;
    cout << "Edad: " << edad << endl;
    cout << "Enfermedad: " << enfermedad << endl;
}
