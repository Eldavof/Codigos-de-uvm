#ifndef EVENTO_H
#define EVENTO_H
#include <string>
#include <iostream>
using std::string;
using namespace std;

class Evento
{
private:
    string tipoComp;
    string sede;
    string fecha;
public:
    int IdEv;

    Evento();
    Evento(int id, const string& tipo, const string& s, const string& f);
    ~Evento();

    void setSede(const string& s);
    string getSede() const;

    void setFecha(const string& f);
    string getFecha() const;

    void setTipComp(const string& t);
    string getTipComp() const;

    void VerificarIdentidadO() const;
    void mostrarInfo() const;
};

#endif // EVENTO_H
