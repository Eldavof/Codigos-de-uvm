#ifndef COMPETIDOR_H
#define COMPETIDOR_H
#include <string>
#include <iostream>
using std::string;
using namespace std;

class Competidor
{
private:
    string nombre;
    int edad;
    string nacionalidad;
    string vehiculo;
    string categoria;
    int penalizaciones;
    float tiempoI;
    float tiempar[3];
public:
    int id;

    Competidor();
    Competidor(const string& n, int e, const string& nac, const string& v, const string& c);
    ~Competidor();

    void setNombre(const string& n);
    string getNombre() const;

    void setEdad(int e);
    int getEdad() const;

    void setVehiculo(const string& v);
    string getVehiculo() const;

    void setCategoria(const string& c);
    string getCategoria() const;

    void setPenalisacion(int p);
    string getPenalisacion() const;

    void setTlempo(float t, int i);
    string getTlempo(int i) const;

    void setTlempoProm(float t);
    string getTlempoProm() const;

    void mostrarInfo() const;
};

#endif // COMPETIDOR_H
