#ifndef ADMINISTRADOR_H
#define ADMINISTRADOR_H
#include <string>
#include <iostream>
using std::string;
using namespace std;

class Evento;

class Administrador
{
private:
    string nombreO;
    string contrasenaO;
    int IdO;
public:
    Administrador();
    Administrador(const string& n, int id, const string& c);
    ~Administrador();

    void setNombreO(const string& n);
    string getNombreO() const;

    void setIdO(int id);
    string getIdO() const;

    void setContrasenaO(const string& c);
    string getContrasenaO() const;

    void actualtarInfo();
    bool crearEvento(Evento* e) const;
    void mostrarInfo() const;
};

#endif // ADMINISTRADOR_H
