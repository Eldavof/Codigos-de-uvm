#ifndef USUARIO_H
#define USUARIO_H
#include <string>
#include <iostream>
using std::string;
using namespace std;

class Usuario
{
private:
    string nombre;
    string contrasena;
public:
    int Id;

    Usuario(const string& n, const string& c, int i);
    ~Usuario();

    void mostrarInfo() const;
    string getNombre() const;
    string getIdU() const;
};

#endif // USUARIO_H
