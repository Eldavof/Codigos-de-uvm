#ifndef EQUIPO_H
#define EQUIPO_H
#include <string>
#include <iostream>
using std::string;
using namespace std;

class Competidor;
class Evento;

class Equipo
{
private:
    string nombreE;
    int numPar;
    string categoriaE;
    Competidor* comp;
    float tiempoPromE;
public:
    int id;
    Evento* ev;

    Equipo();
    Equipo(int id, const string& nom, const string& categ, float itempProm);
    ~Equipo();

    void setNombreE(const string& n);
    string getNombreE() const;

    void setCategoriaE(const string& c);
    string getCategoriaE() const;

    void setTlempoPromE(float t);
    float getTlempoPromE() const;

    void mostrarInfo() const;
    void asignarCompetidor(Competidor* c);
};

#endif // EQUIPO_H
