#include "Equipo.h"
#include "Competidor.h"
#include "Evento.h"
#include <string>
#include <iostream>
using namespace std;

Equipo::Equipo() : nombreE(""), numPar(0), categoriaE(""), comp(nullptr),
                   tiempoPromE(0.0f), id(0), ev(nullptr) {}

Equipo::Equipo(int i, const string& n, const string& c, float itempProm)
    : nombreE(n), id(i), numPar(0), categoriaE(c), comp(nullptr),
      tiempoPromE(itempProm), ev(nullptr)
{
    std::cout << "Equipo " << nombreE << " creado.\n";
}

Equipo::~Equipo() {
    std::cout << "Equipo " << nombreE << " disuelto.\n";
}

void Equipo::setNombreE(const string& n) { nombreE = n; }
string Equipo::getNombreE() const { return nombreE; }

void Equipo::setCategoriaE(const string& c) { categoriaE = c; }
string Equipo::getCategoriaE() const { return categoriaE; }

void Equipo::setTlempoPromE(float t) { tiempoPromE = t; }
float Equipo::getTlempoPromE() const { return tiempoPromE; }

void Equipo::asignarCompetidor(Competidor* c) {
    comp = c;
    numPar++;
    std::cout << "Competidor asignado al equipo " << nombreE << ".\n";
}

void Equipo::mostrarInfo() const {
    std::cout << "\n--- Informaci�n del Equipo ---\n";
    std::cout << "Nombre del equipo: " << nombreE << "\nID: " << id
              << "\nCategor�a: " << categoriaE << "\nTiempo promedio: " << tiempoPromE
              << "\nN�mero de participantes: " << numPar << "\n";
    if (comp) {
        std::cout << "Competidor asignado:\n";
        comp->mostrarInfo();
    } else {
        std::cout << "Sin competidor asignado.\n";
    }
}
