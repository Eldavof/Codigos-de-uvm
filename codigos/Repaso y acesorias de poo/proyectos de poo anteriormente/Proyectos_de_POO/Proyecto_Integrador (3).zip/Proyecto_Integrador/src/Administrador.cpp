#include "Administrador.h"
#include "Evento.h"
#include <string>
#include <iostream>
using namespace std;

Administrador::Administrador() : nombreO(""), IdO(0), contrasenaO("") {}

Administrador::Administrador(const string& n, int id, const string& c)
    : nombreO(n), IdO(id), contrasenaO(c)
{
    cout << "Administrador " << nombreO << " dado de alta.\n";
}

Administrador::~Administrador() {
    cout << "Administrador " << nombreO << " eliminado del sistema.\n";
}

void Administrador::setNombreO(const string& n) { nombreO = n; }
string Administrador::getNombreO() const { return nombreO; }

void Administrador::setIdO(int id) { IdO = id; }
string Administrador::getIdO() const { return to_string(IdO); }

void Administrador::setContrasenaO(const string& c) { contrasenaO = c; }
string Administrador::getContrasenaO() const { return contrasenaO; }

void Administrador::actualtarInfo() {
    cout << "Informaci�n del administrador actualizada.\n";
}

bool Administrador::crearEvento(Evento* e) const {
    string passwordIngresada;
    cout << "\nPara crear el evento, por favor ingrese la contrase�a del administrador: ";
    cin >> passwordIngresada;

    // Comparamos la contrase�a ingresada con la del objeto actual
    if (passwordIngresada == this->contrasenaO) {
        cout << "Contrase�a correcta. Acceso concedido.\n";
        cout << "--------------------------------------\n";
        cout << "Administrador '" << nombreO << "' ha creado un evento:\n";
        if (e) {
            e->mostrarInfo();
        }
        return true; // La operaci�n fue exitosa
    } else {
        cout << "\n*** Contrase�a incorrecta. Acceso denegado. ***\n";
        cout << "No se puede crear el evento.\n";
        return false; // La operaci�n fall�
    }
}

void Administrador::mostrarInfo() const {
    cout << "\n--- Informaci�n del Administrador ---\n";
    cout << "Nombre: " << nombreO << "\nID: " << IdO << "\n";
}
