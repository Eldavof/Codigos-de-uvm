#include "Usuario.h"
#include <string>
#include <iostream>
using namespace std;

Usuario::Usuario(const string& n, const string& c, int i)
    : nombre(n), contrasena(c), Id(i)
{
    std::cout << "Usuario " << nombre << " registrado exitosamente.\n";
}

Usuario::~Usuario() {
    std::cout << "Usuario " << nombre << " eliminado del sistema.\n";
}

void Usuario::mostrarInfo() const {
    std::cout << "\n--- Informaci�n del Usuario ---\n";
    std::cout << "Nombre: " << nombre << "\nID: " << Id << "\n";
}

string Usuario::getNombre() const { return nombre; }
string Usuario::getIdU() const { return to_string(Id); }
