#include "Evento.h"
#include <string>
#include <iostream>
using namespace std;

Evento::Evento() : IdEv(0), tipoComp(""), sede(""), fecha("") {}

Evento::Evento(int id, const string& tipo, const string& s, const string& f)
    : IdEv(id), tipoComp(tipo), sede(s), fecha(f)
{
    cout << "Evento " << tipoComp << " creado.\n";
}

Evento::~Evento() {
    cout << "Evento " << tipoComp << " finalizado.\n";
}

void Evento::setSede(const string& s) { sede = s; }
string Evento::getSede() const { return sede; }

void Evento::setFecha(const string& f) { fecha = f; }
string Evento::getFecha() const { return fecha; }

void Evento::setTipComp(const string& t) { tipoComp = t; }
string Evento::getTipComp() const { return tipoComp; }

void Evento::mostrarInfo() const {
    cout << "\n--- Informaci�n del Evento ---\n";
    cout << "ID: " << IdEv << "\nTipo de competencia: " << tipoComp
              << "\nSede: " << sede << "\nFecha: " << fecha << "\n";
}

void Evento::VerificarIdentidadO() const {
    cout << "Verificando identidad del organizador... (simulado)\n";
}
