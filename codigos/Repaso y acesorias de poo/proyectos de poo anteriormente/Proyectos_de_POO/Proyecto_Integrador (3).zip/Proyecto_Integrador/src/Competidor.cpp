#include "Competidor.h"
#include <string>
#include <sstream>
#include <iostream>
using namespace std;

Competidor::Competidor() : nombre(""), edad(0), nacionalidad(""), vehiculo(""), categoria(""),
                          penalizaciones(0), tiempoI(0.0f), id(0)
{
    for (int i = 0; i < 3; ++i) tiempar[i] = 0.0f;
}

Competidor::Competidor(const string& n, int e, const string& nac, const string& v, const string& c)
    : nombre(n), edad(e), nacionalidad(nac), vehiculo(v), categoria(c),
      penalizaciones(0), tiempoI(0.0f), id(0)
{
    for (int i = 0; i < 3; ++i) tiempar[i] = 0.0f;
    std::cout << "Competidor " << nombre << " registrado exitosamente.\n";
}

Competidor::~Competidor() {
    std::cout << "Competidor " << nombre << " eliminado del sistema.\n";
}

void Competidor::setNombre(const string& n) { nombre = n; }
string Competidor::getNombre() const { return nombre; }

void Competidor::setEdad(int e) { edad = e; }
int Competidor::getEdad() const { return edad; }

void Competidor::setVehiculo(const string& v) { vehiculo = v; }
string Competidor::getVehiculo() const { return vehiculo; }

void Competidor::setCategoria(const string& c) { categoria = c; }
string Competidor::getCategoria() const { return categoria; }

void Competidor::setPenalisacion(int p) { penalizaciones = p; }
string Competidor::getPenalisacion() const {
    return to_string(penalizaciones);
}

void Competidor::setTlempo(float t, int i) {
    if (i >= 0 && i < 3) tiempar[i] = t;
}

string Competidor::getTlempo(int i) const {
    if (i >= 0 && i < 3) return to_string(tiempar[i]);
    return "0.0";
}

void Competidor::setTlempoProm(float t) { tiempoI = t; }
string Competidor::getTlempoProm() const {
    return to_string(tiempoI);
}

void Competidor::mostrarInfo() const {
    std::cout << "\n--- Datos del Competidor ---\n";
    std::cout << "Nombre: " << nombre << "\nEdad: " << edad << "\nNacionalidad: " << nacionalidad
              << "\nVeh�culo: " << vehiculo << "\nCategor�a: " << categoria
              << "\nPenalizaciones: " << penalizaciones << "\nTiempo promedio: " << tiempoI << "\n";
}
