#include <iostream>
#include <clocale>
#include <string>
#include <locale>
#include "Competidor.h"
#include "Equipo.h"
#include "Evento.h"
#include "Administrador.h"
#include "Usuario.h"
using namespace std;

int main() {
    setlocale(LC_CTYPE, "spanish");

    int opc;
    Competidor* comp = nullptr;
    Equipo* eq = nullptr;
    Evento* ev = nullptr;
    Administrador* admin = nullptr;
    Usuario* user = nullptr;

    do {
        cout << "\n===== MEN� DEL SISTEMA DE COMPETENCIAS =====\n";
        cout << "1. Registrar Competidor\n";
        cout << "2. Crear Equipo\n";
        cout << "3. Crear Evento\n";
        cout << "4. Registrar Administrador\n";
        cout << "5. Registrar Usuario\n";
        cout << "6. Mostrar Informaci�n\n";
        cout << "0. Salir\n";
        cout << "Opci�n: ";
        cin >> opc;
        cin.ignore();

        switch (opc) {
            case 1: {
                string nom, nac, veh, cat;
                int edad;
                cout << "Nombre del competidor: ";
                getline(cin, nom);
                cout << "Edad: ";
                cin >> edad; cin.ignore();
                cout << "Nacionalidad: ";
                getline(cin, nac);
                cout << "Veh�culo: ";
                getline(cin, veh);
                cout << "Categor�a: ";
                getline(cin, cat);
                comp = new Competidor(nom, edad, nac, veh, cat);
                break;
            }
            case 2: {
                string nombreE, categoriaE;
                int id;
                float itempProm;
                cout << "Nombre del equipo: ";
                getline(cin, nombreE);
                cout << "ID: ";
                cin >> id; cin.ignore();
                cout << "Categor�a: ";
                getline(cin, categoriaE);
                cout << "Tiempo promedio del equipo: ";
                cin >> itempProm; cin.ignore();

                eq = new Equipo(id, nombreE, categoriaE, itempProm);
                if (comp) eq->asignarCompetidor(comp);
                break;
            }
            case 3: {
                if (!admin) {
                    cout << "\nERROR: Debe registrar un administrador (opci�n 4) antes de poder crear un evento.\n";
                    break;
                }

                // 2. Si hay admin, pedimos los datos del evento
                int id;
                string tipo, sede, fecha;
                cout << "ID del evento: ";
                cin >> id; cin.ignore();
                cout << "Tipo de competencia: ";
                getline(cin, tipo);
                cout << "Sede: ";
                getline(cin, sede);
                cout << "Fecha: ";
                getline(cin, fecha);

                // Creamos un evento temporal
                Evento* nuevoEvento = new Evento(id, tipo, sede, fecha);

                // 3. Llamamos a la funci�n que pide la contrase�a
                bool exito = admin->crearEvento(nuevoEvento);

                // 4. Verificamos si la contrase�a fue correcta
                if (exito) {
                    // Si ya hab�a un evento, lo borramos para no tener fugas de memoria
                    delete ev;
                    // Asignamos el nuevo evento al puntero principal
                    ev = nuevoEvento;
                    cout << "\n[SISTEMA] Evento registrado exitosamente.\n";
                } else {
                    // Si la contrase�a fue incorrecta, el evento no se crea,
                    // as� que borramos el objeto temporal que creamos.
                    delete nuevoEvento;
                    cout << "\n[SISTEMA] El evento no fue registrado.\n";
            }
            break;
            }
            case 4: {
                string nom, contra;
                int id;
                cout << "Nombre del administrador: ";
                getline(cin, nom);
                cout << "ID: ";
                cin >> id; cin.ignore();
                cout << "Contrase�a: ";
                getline(cin, contra);
                admin = new Administrador(nom, id, contra);
                break;
            }
            case 5: {
                string nom, contra;
                int id;
                cout << "Nombre del usuario: ";
                getline(cin, nom);
                cout << "Contrase�a: ";
                getline(cin, contra);
                cout << "ID: ";
                cin >> id; cin.ignore();
                user = new Usuario(nom, contra, id);
                break;
            }
            case 6: {
                if (comp) comp->mostrarInfo();
                if (eq) eq->mostrarInfo();
                if (ev) ev->mostrarInfo();
                if (admin) admin->mostrarInfo();
                if (user) user->mostrarInfo();
                break;
            }
            case 0:
                cout << "Saliendo del sistema..." << endl;
                break;
            default:
                cout << "Opci�n no v�lida." << endl;
        }
    } while (opc != 0);

    // Liberar memoria
    delete comp;
    delete eq;
    delete ev;
    delete admin;
    delete user;

    return 0;
}
